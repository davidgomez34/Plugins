<?php
/**
 * Plugin Name: DES-Box
 * Description: Loads and manages plugins from a subdirectory with enhanced security and error handling
 * Version: 1.1
 * Author: David Gomez
 * Author URI: https://digitalenterstudio.com
 * License: GPL2
 */

defined('ABSPATH') or die('Direct access not allowed');

class DES_Box_Loader {
    const PLUGIN_DIR = 'included-plugins';

    public function init() {
        add_action('plugins_loaded', [$this, 'load_plugins']);
    }

    public function load_plugins() {
        $plugin_dir = trailingslashit(plugin_dir_path(__FILE__)) . self::PLUGIN_DIR;
        
        try {
            if (!is_dir($plugin_dir)) {
                if (!wp_mkdir_p($plugin_dir)) {
                    error_log('DES-Box: Failed to create plugin directory');
                    return;
                }
            }

            // Recursively scan for PHP files in all subdirectories
            $plugins = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($plugin_dir)
            );
            $plugins = array_keys(array_filter(
                iterator_to_array($plugins),
                function($file) {
                    return $file->isFile() && 
                           $file->getExtension() === 'php' &&
                           strpos($file->getPathname(), '/.') === false; // Skip hidden directories
                }
            ));
            
            if (empty($plugins)) {
                return;
            }

            $loaded_plugins = 0;
            
            // Sort plugins alphabetically to ensure consistent loading
            sort($plugins);
            
            foreach ($plugins as $plugin) {
                try {
                    if (!is_file($plugin) || !is_readable($plugin)) {
                        error_log("DES-Box: Skipping unreadable plugin - $plugin");
                        continue;
                    }

                    // Verify this is a valid plugin file
                    $plugin_data = get_file_data($plugin, [
                        'Name' => 'Plugin Name',
                        'Version' => 'Version',
                        'TextDomain' => 'Text Domain'
                    ]);

                    if (empty($plugin_data['Name'])) {
                        error_log("DES-Box: Skipping invalid plugin header - $plugin");
                        continue;
                    }

                    include_once $plugin;
                    $loaded_plugins++;

                    // Register hooks
                    register_activation_hook($plugin, function() use ($plugin_data) {
                        error_log("DES-Box: Activating plugin - {$plugin_data['Name']}");
                        // Activation code here
                    });

                    register_deactivation_hook($plugin, function() use ($plugin_data) {
                        error_log("DES-Box: Deactivating plugin - {$plugin_data['Name']}");
                        // Deactivation code here
                    });

                    register_uninstall_hook($plugin, function() use ($plugin_data) {
                        error_log("DES-Box: Uninstalling plugin - {$plugin_data['Name']}");
                        // Uninstall cleanup code here
                    });

                    error_log("DES-Box: Successfully loaded plugin - {$plugin_data['Name']}");

                } catch (Exception $e) {
                    error_log("DES-Box: Error loading plugin $plugin - " . $e->getMessage());
                }
            }
            
            if ($loaded_plugins > 0) {
                error_log("DES-Box: Successfully loaded $loaded_plugins plugins:");
                foreach ($plugins as $plugin) {
                    $plugin_data = get_file_data($plugin, [
                        'Name' => 'Plugin Name',
                        'Version' => 'Version'
                    ]);
                    if (!empty($plugin_data['Name'])) {
                        error_log("- Loaded: " . $plugin_data['Name'] . " v" . ($plugin_data['Version'] ?? '1.0'));
                    } else {
                        error_log("- Skipped (invalid header): $plugin");
                    }
                }
            } else {
                error_log('DES-Box: No valid plugins found in included-plugins directory');
            }
            
            // Debug: List all found PHP files
            error_log("DES-Box: Scanned files in included-plugins:");
            foreach ($plugins as $plugin) {
                error_log("- Found: $plugin");
            }
        } catch (Exception $e) {
            error_log('DES-Box Error: ' . $e->getMessage());
        }
    }
}

(new DES_Box_Loader())->init();
