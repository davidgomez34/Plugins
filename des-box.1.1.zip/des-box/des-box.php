<?php
/**
 * Plugin Name: DES-Box
 * Description: Loads and manages plugins from a subdirectory with enhanced security and error handling
 * Version: 1.1
 * Author: David Gomez
 * Author URI: https://digitalenterstudio.com
 * License: GPL2
 */

defined('ABSPATH') or die('Direct access not allowed');

class DES_Box_Loader {
    const PLUGIN_DIR = 'included-plugins';

    public function init() {
        add_action('plugins_loaded', [$this, 'load_plugins']);
    }

    public function load_plugins() {
        $plugin_dir = trailingslashit(plugin_dir_path(__FILE__)) . self::PLUGIN_DIR;
        
        try {
            if (!is_dir($plugin_dir)) {
                if (!wp_mkdir_p($plugin_dir)) {
                    error_log('DES-Box: Failed to create plugin directory');
                    return;
                }
            }

            $plugins = glob($plugin_dir . '/*.php');
            
            if (empty($plugins)) {
                return;
            }

            foreach ($plugins as $plugin) {
                if (!is_file($plugin) || !is_readable($plugin)) {
                    continue;
                }

                // Verify this is a valid plugin file
                $plugin_data = get_file_data($plugin, [
                    'Name' => 'Plugin Name',
                    'Version' => 'Version',
                    'TextDomain' => 'Text Domain'
                ]);

                if (empty($plugin_data['Name'])) {
                    continue;
                }

                include_once $plugin;

                // Register hooks
                register_activation_hook($plugin, function() use ($plugin_data) {
                    // Activation code here
                });

                register_deactivation_hook($plugin, function() use ($plugin_data) {
                    // Deactivation code here
                });

                register_uninstall_hook($plugin, function() use ($plugin_data) {
                    // Uninstall cleanup code here
                });
            }
        } catch (Exception $e) {
            error_log('DES-Box Error: ' . $e->getMessage());
        }
    }
}

(new DES_Box_Loader())->init();
