# DES-Box Plugin Loader

## Description
A WordPress plugin that loads and manages other plugins from a subdirectory (`included-plugins/`).

## Features
- Loads all valid WordPress plugins from the `included-plugins` directory
- Supports activation, deactivation, and uninstall hooks for loaded plugins
- Includes enhanced security and error handling
- Automatically creates the plugin directory if missing

## Installation
1. Upload the `des-box` folder to your `/wp-content/plugins/` directory
2. Activate the plugin through the WordPress plugins page
3. Create an `included-plugins` directory inside the `des-box` folder
4. Place your additional plugins (as .php files) in this directory

## Usage
- All valid WordPress plugins placed in the `included-plugins` directory will be automatically loaded
- Each plugin must have standard WordPress plugin headers to be recognized
- The following hooks are available for loaded plugins:
  - Activation hook (runs when plugin is activated)
  - Deactivation hook (runs when plugin is deactivated)
  - Uninstall hook (runs when plugin is deleted)

## Requirements
- WordPress 5.0 or higher
- PHP 7.4 or higher

## Version History
- 1.1 (Current)
  - Added uninstall hook support
  - Improved error handling
  - Better code organization
- 1.0
  - Initial release

## Author  
[David Gomez](https://digitalenterstudio.com)

## Support  
For support or feature requests, please contact the plugin author.
