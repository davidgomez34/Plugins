=== DES-Box ===
Contributors: David Gomez
Donate link: https://digitalenterstudio.com
Tags: plugin loader, plugin manager
Requires at least: WordPress 5.0
Tested up to: WordPress 6.4
Stable tag: 1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Loads and manages WordPress plugins from a subdirectory with enhanced security and error handling.

== Description ==

DES-Box is a WordPress plugin that automatically loads and manages other plugins placed in its 'included-plugins' subdirectory. It provides:

* Automatic plugin loading from subdirectory
* Support for activation/deactivation hooks
* Enhanced security checks
* Automatic directory creation
* Error handling and logging

== Installation ==

1. Upload the `des-box` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through 'Plugins' menu in WordPress
3. Create an `included-plugins` subdirectory
4. Place your plugin files (PHP) in this directory

== Frequently Asked Questions ==

= What file types are supported? =
Only .php files with valid WordPress plugin headers are loaded.

= Where should I put my plugins? =
In the 'included-plugins' subdirectory within the des-box folder.

= How do I know if my plugin loaded correctly? =
Check your PHP error logs and WordPress debug log.

== Changelog ==

= 1.1 =
* Added uninstall hook support
* Improved error handling
* Added documentation

= 1.0 =
* Initial release

== Upgrade Notice ==

1.1 = Recommended update with improved stability and features
